package com.marine.website.board;


import com.marine.website.board.boarddto.BoardDTO;
import com.marine.website.user.SiteUser;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @GetMapping("/board/getList")
    public List<SiteUser> getBoardListAll() {
        return boardService.boardList();
    }

    @PostMapping("/board/create")
    public Long createBoard(@RequestBody BoardDTO boardDTO) {
        Long id = boardService.save(boardDTO);
        return id;
    }
}
