package com.marine.website.board;


import org.springframework.stereotype.Repository;
import com.querydsl.jpa.impl.JPAQueryFactory;

import javax.persistence.EntityManager;

@Repository
public class BoardRepositoryDsl {
    private final EntityManager em;
    private JPAQueryFactory query;
    public BoardRepositoryDsl(EntityManager em) {
        this.em = em;
        this.query = new JPAQueryFactory(em); // 이 방식을 스프링 빈 방식으로 할 수 있다.  (QuerydslApplication 에 빈으로 등록)
    }

    public Long save(Board board) {
        em.persist(board);
        return board.getId();
    }




}
