package com.marine.website.board;

import com.marine.website.board.boarddto.BoardDTO;
import com.marine.website.category.Category;
import com.marine.website.category.CategoryRepository;
import com.marine.website.category.CategoryService;
import com.marine.website.user.SiteUser;
import com.marine.website.user.UserRepository;
import com.marine.website.user.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardRepository boardRepository;
    private final BoardRepositoryDsl boardRepositoryDsl;

    private final UserService userService;
    private final CategoryService categoryService;
    public Long save(BoardDTO boardDTO) {
        Board board = new Board();
        board.setTitle(boardDTO.getTitle());
        board.setContext(boardDTO.getContext());

        board.setCategory(categoryService.getCategoryByName(boardDTO.getCategoryName()));
        board.setUser(userService.getUser(boardDTO.getUsername()));

        Long id = boardRepositoryDsl.save(board);
        return id;

    }


    public List<SiteUser> boardList() {
        return boardRepository.findAll();
    }

    public Optional<List<Board>> findByName(String name) {
        return boardRepository.findByName(name);
    }


}
