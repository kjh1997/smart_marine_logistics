package com.marine.website.category;

public class CategoryRepositoryDsl {
}
