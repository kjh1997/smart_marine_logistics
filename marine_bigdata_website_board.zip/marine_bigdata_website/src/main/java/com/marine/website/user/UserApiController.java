package com.marine.website.user;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserApiController {
}
