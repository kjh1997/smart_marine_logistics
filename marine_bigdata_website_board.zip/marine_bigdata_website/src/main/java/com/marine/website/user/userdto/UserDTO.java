package com.marine.website.user.userdto;

public class UserDTO {

}
